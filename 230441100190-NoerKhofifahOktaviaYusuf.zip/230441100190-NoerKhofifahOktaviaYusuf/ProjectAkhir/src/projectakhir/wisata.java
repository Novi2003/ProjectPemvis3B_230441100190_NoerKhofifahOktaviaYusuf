/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.table.DefaultTableModel;



public class wisata extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel modelTiket;
    private DefaultTableModel modelPenginapan;
    private JDateChooser tglmasuk; 
    private JDateChooser tglkeluar;
    

    public wisata() {

        initComponents();
        if (!ProjectAkhir.isLoggedIn) {
            JOptionPane.showMessageDialog(
                null,
                "Anda harus login terlebih dahulu!",
                "Peringatan",
                JOptionPane.WARNING_MESSAGE
            );
            new login().setVisible(true); // Tampilkan halaman login
            this.dispose(); // Tutup halaman wisata
            return; // Hentikan eksekusi jika belum login
        }
        
        tglmasuk = new JDateChooser();
        tglkeluar = new JDateChooser();
        conn = koneksi.getConnection();
        
        modelTiket = new DefaultTableModel();
        tbl_Tiket.setModel(modelTiket);
        modelTiket.addColumn("ID");
        modelTiket.addColumn("Harga");
        modelTiket.addColumn("Jumlah Tiket");
        modelTiket.addColumn("Total");
        loadDataTiket();
        
        modelPenginapan= new DefaultTableModel();
        tbl_penginapan.setModel(modelPenginapan);
        modelPenginapan.addColumn("Nama");
        modelPenginapan.addColumn("Alamat");
        modelPenginapan.addColumn("NIK");
        modelPenginapan.addColumn("Harga");
        modelPenginapan.addColumn("Tgl check-in");
        modelPenginapan.addColumn("Tgl check-out");
        modelPenginapan.addColumn("JumlahHari");
        modelPenginapan.addColumn("Total");
        loadDataPenginapan();
    }
    
    private void loadDataTiket() {
    modelTiket.setRowCount(0);
    try {
        String sql = "SELECT * FROM tiket";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            modelTiket.addRow(new Object[]{
                rs.getInt("id_tiket"),
                rs.getInt("Harga"),
                rs.getInt("Jumlah_Tiket"),
                rs.getInt("Total")
            });
        }
    } catch (SQLException e) {
        System.out.println("Error Load Data: " + e.getMessage());
        e.printStackTrace(); 
    }
    }
    
    private void loadDataPenginapan() {
    modelPenginapan.setRowCount(0);
    try {
        String sql = "SELECT * FROM penginapan";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            modelPenginapan.addRow(new Object[]{
                rs.getString("Nama"),
                rs.getString("Alamat"),
                rs.getInt("NIK"),
                rs.getInt("Harga"),
                rs.getDate("TglCheckIn"),
                rs.getDate("TglCheckOut"),
                rs.getInt("JumlahHari"),
                rs.getInt("Total")
            });
        }
    } catch (SQLException e) {
        System.out.println("Error Load Data: " + e.getMessage());
        e.printStackTrace(); 
    }
    }
    
    private int getSelectedHarga() {
        if (RBVVIP.isSelected()){
            return 3000000;
        }else if (RBVIP.isSelected()){
            return 2500000;
        }else if (RBSVIP.isSelected()){
            return 2000000;
        }else if (RBElit.isSelected()){
            return 1500000;
        }else if (RBMewah.isSelected()){
            return 1000000;
        }else if (RBBiasa.isSelected()){
            return 500000;
        }
        return 0;  
    }
    
    private void clearInputFieldsTiket(){
        IdTiket.setText("");
        HargaTiket.setText("");
        Jumlahtiket.setText("");
        TotalTiket.setText("");
    }

    private void clearInputFieldsPenginapan(){
        tfNama.setText("");
        tfAlamat.setText("");
        tfNIK.setText("");
        tglChekIn.setDate(null);
        tglCheckOut.setDate(null);
        tfJumlahHari.setText("");
        tfTotal.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Harga = new javax.swing.ButtonGroup();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        IdTiket = new javax.swing.JTextField();
        HargaTiket = new javax.swing.JTextField();
        Jumlahtiket = new javax.swing.JTextField();
        TotalTiket = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Tiket = new javax.swing.JTable();
        jBTambahTiket = new javax.swing.JButton();
        jBEditTiket = new javax.swing.JButton();
        jBDeletetiket = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        tfNama = new javax.swing.JTextField();
        tfAlamat = new javax.swing.JTextField();
        tfNIK = new javax.swing.JTextField();
        tfJumlahHari = new javax.swing.JTextField();
        tfTotal = new javax.swing.JTextField();
        JBEditPenginapan = new javax.swing.JButton();
        jBTambahPenginapan = new javax.swing.JButton();
        JBDeletePenginapan = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_penginapan = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        RBElit = new javax.swing.JRadioButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        RBMewah = new javax.swing.JRadioButton();
        jPanel14 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        RBBiasa = new javax.swing.JRadioButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        RBVVIP = new javax.swing.JRadioButton();
        jPanel13 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        RBVIP = new javax.swing.JRadioButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        RBSVIP = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        tglChekIn = new com.toedter.calendar.JDateChooser();
        tglCheckOut = new com.toedter.calendar.JDateChooser();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        jLabel7.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Puncak Ratu", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Rockwell Extra Bold", 3, 12))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(0, 204, 204));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel2.setText("ID :");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel4.setText("Harga :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel5.setText("Jumlah Tiket :");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel6.setText("Total :");

        IdTiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IdTiketActionPerformed(evt);
            }
        });

        Jumlahtiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JumlahtiketActionPerformed(evt);
            }
        });

        TotalTiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalTiketActionPerformed(evt);
            }
        });

        tbl_Tiket.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        tbl_Tiket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Harga", "Jumlah Tiket", "Total"
            }
        ));
        tbl_Tiket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_TiketMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_Tiket);

        jBTambahTiket.setBackground(new java.awt.Color(0, 0, 0));
        jBTambahTiket.setForeground(new java.awt.Color(51, 255, 204));
        jBTambahTiket.setText("Tambah");
        jBTambahTiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBTambahTiketActionPerformed(evt);
            }
        });

        jBEditTiket.setBackground(new java.awt.Color(0, 0, 0));
        jBEditTiket.setForeground(new java.awt.Color(51, 255, 204));
        jBEditTiket.setText("Edit");
        jBEditTiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEditTiketActionPerformed(evt);
            }
        });

        jBDeletetiket.setBackground(new java.awt.Color(0, 0, 0));
        jBDeletetiket.setForeground(new java.awt.Color(51, 255, 204));
        jBDeletetiket.setText("Delete");
        jBDeletetiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBDeletetiketActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(0, 153, 153));

        jLabel8.setFont(new java.awt.Font("Segoe Print", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Pembelian Tiket");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/gmbr1.png"))); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/gmbr2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel6))
                                    .addGap(71, 71, 71)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                            .addComponent(IdTiket, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(37, 37, 37)
                                            .addComponent(jBTambahTiket))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(HargaTiket, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Jumlahtiket, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(TotalTiket, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel4Layout.createSequentialGroup()
                                                    .addGap(37, 37, 37)
                                                    .addComponent(jBDeletetiket))
                                                .addGroup(jPanel4Layout.createSequentialGroup()
                                                    .addGap(38, 38, 38)
                                                    .addComponent(jBEditTiket))))))))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel9))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(IdTiket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(11, 11, 11)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(HargaTiket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Jumlahtiket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TotalTiket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addComponent(jBTambahTiket)
                                .addGap(18, 18, 18)
                                .addComponent(jBEditTiket)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jBDeletetiket, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(94, 94, 94))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))))
        );

        jTabbedPane2.addTab("Pembelian Tiket", jPanel4);

        jPanel9.setBackground(new java.awt.Color(0, 204, 204));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel21.setText("Nama");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel22.setText("Alamat");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel23.setText("NIK");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel24.setText("Jumlah Hari");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel25.setText("Total");

        JBEditPenginapan.setBackground(new java.awt.Color(0, 0, 0));
        JBEditPenginapan.setForeground(new java.awt.Color(51, 255, 204));
        JBEditPenginapan.setText("Edit");
        JBEditPenginapan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBEditPenginapanActionPerformed(evt);
            }
        });

        jBTambahPenginapan.setBackground(new java.awt.Color(0, 0, 0));
        jBTambahPenginapan.setForeground(new java.awt.Color(51, 255, 204));
        jBTambahPenginapan.setText("Tambah");
        jBTambahPenginapan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBTambahPenginapanActionPerformed(evt);
            }
        });

        JBDeletePenginapan.setBackground(new java.awt.Color(0, 0, 0));
        JBDeletePenginapan.setForeground(new java.awt.Color(51, 255, 204));
        JBDeletePenginapan.setText("Delete");
        JBDeletePenginapan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBDeletePenginapanActionPerformed(evt);
            }
        });

        tbl_penginapan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nama", "Alamat", "NIK", "Harga", "Tgl chek-in", "Tgl chek-out", "Jumlah Hari", "Total"
            }
        ));
        tbl_penginapan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_penginapanMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_penginapan);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jPanel11.setBackground(new java.awt.Color(67, 130, 130));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/elite.jpg"))); // NOI18N
        jLabel12.setText("Elit");
        jLabel12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel12.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBElit);
        RBElit.setText("1.500.000");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(RBElit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RBElit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(67, 130, 130));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/medium.jpg"))); // NOI18N
        jLabel17.setText("Mewah");
        jLabel17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel17.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBMewah);
        RBMewah.setText("1000.000");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RBMewah)
                .addGap(26, 26, 26))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RBMewah, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        jPanel14.setBackground(new java.awt.Color(67, 130, 130));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/normal.jpg"))); // NOI18N
        jLabel19.setText("Biasa");
        jLabel19.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel19.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBBiasa);
        RBBiasa.setText("500.000");
        RBBiasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RBBiasaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(RBBiasa))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RBBiasa)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(67, 130, 130));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/vvip.jpg"))); // NOI18N
        jLabel20.setText("VVIP");
        jLabel20.setFocusable(false);
        jLabel20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel20.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBVVIP);
        RBVVIP.setText("3.000.000");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(RBVVIP)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RBVVIP)
                .addGap(12, 12, 12))
        );

        jPanel13.setBackground(new java.awt.Color(67, 130, 130));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/vip.jpg"))); // NOI18N
        jLabel18.setText("VIP");
        jLabel18.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel18.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBVIP);
        RBVIP.setText("2.500.000");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(RBVIP)))
                .addGap(0, 10, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RBVIP)
                .addContainerGap())
        );

        jPanel10.setBackground(new java.awt.Color(67, 130, 130));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhir/svip.jpg"))); // NOI18N
        jLabel10.setText("SVIP");
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel10.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        Harga.add(RBSVIP);
        RBSVIP.setText("2000.000");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(RBSVIP)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RBSVIP, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        jLabel3.setFont(new java.awt.Font("Lucida Handwriting", 3, 14)); // NOI18N
        jLabel3.setText("Jenis Kamar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        jLabel27.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel27.setText("Tgl chek-in");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel28.setText("Tgl chek-out");

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setFont(new java.awt.Font("Segoe Print", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Pemesanan Penginapan");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel1)
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel23))
                                .addGap(42, 42, 42))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel27)
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel28)
                                            .addGroup(jPanel9Layout.createSequentialGroup()
                                                .addComponent(jLabel25)
                                                .addGap(37, 37, 37)))
                                        .addComponent(jLabel24))
                                    .addComponent(jBTambahPenginapan, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(JBEditPenginapan)
                                .addGap(18, 18, 18)
                                .addComponent(JBDeletePenginapan))
                            .addComponent(tfNama)
                            .addComponent(tfAlamat)
                            .addComponent(tfNIK)
                            .addComponent(tglChekIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tglCheckOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfJumlahHari)
                            .addComponent(tfTotal))
                        .addGap(85, 85, 85)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(241, 241, 241)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(810, 810, 810))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfNIK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27)
                            .addComponent(tglChekIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tglCheckOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfJumlahHari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JBEditPenginapan)
                                .addComponent(jBTambahPenginapan))
                            .addComponent(JBDeletePenginapan))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Pemesanan Penginapan", jPanel9);

        jLabel16.setFont(new java.awt.Font("Script MT Bold", 3, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("TRANSAKSI WISATA PUNCAK RATU");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 603, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IdTiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IdTiketActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IdTiketActionPerformed

    private void jBTambahTiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBTambahTiketActionPerformed
    try {
        int harga = Integer.parseInt(HargaTiket.getText());
        int jumlah = Integer.parseInt(Jumlahtiket.getText());
        
        // Menghitung total harga
        int totalHarga = harga * jumlah;
        TotalTiket.setText(""+totalHarga);
        
        
        // Menambahkan data ke database
        String sql = "INSERT INTO tiket ( Harga, Jumlah_Tiket, Total) VALUES ( ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, harga);
        ps.setInt(2, jumlah);
        ps.setInt(3, totalHarga);
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan");
        
        loadDataTiket();
        clearInputFieldsTiket();
    } catch (SQLException e) {
        System.out.println("Error Save Data: " + e.getMessage());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Input data tidak valid: " + e.getMessage());
    }
    }//GEN-LAST:event_jBTambahTiketActionPerformed

    private void TotalTiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalTiketActionPerformed

    }//GEN-LAST:event_TotalTiketActionPerformed

    private void tbl_TiketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_TiketMouseClicked
      IdTiket.setText(tbl_Tiket.getValueAt(tbl_Tiket.getSelectedRow(), 0).toString());
      HargaTiket.setText(tbl_Tiket.getValueAt(tbl_Tiket.getSelectedRow(), 1).toString());
      Jumlahtiket.setText(tbl_Tiket.getValueAt(tbl_Tiket.getSelectedRow(), 2).toString());
      TotalTiket.setText(tbl_Tiket.getValueAt(tbl_Tiket.getSelectedRow(), 3).toString());
      jBTambahTiket.setEnabled(true);
      jBEditTiket.setEnabled(true);
      jBDeletetiket.setEnabled(true);
    }//GEN-LAST:event_tbl_TiketMouseClicked

    private void JumlahtiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JumlahtiketActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JumlahtiketActionPerformed

    private void jBEditTiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEditTiketActionPerformed
        int idTiket = Integer.parseInt(IdTiket.getText());
        int harga = Integer.parseInt(HargaTiket.getText());
        int jumlah = Integer.parseInt(Jumlahtiket.getText());
        int total = Integer.parseInt(TotalTiket.getText());
       
        // Menghitung total harga
        int totalHarga = harga * jumlah;
        TotalTiket.setText(""+totalHarga);
        
        try {
            String sql = "UPDATE tiket SET Harga = ?, Jumlah_Tiket = ?, Total = ? WHERE id_tiket = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, harga);
            ps.setInt(2, jumlah);
            ps.setInt(3, totalHarga);
            ps.setInt(4, idTiket);  
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil di Edit");

            loadDataTiket();
            clearInputFieldsTiket();
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
        }

    }//GEN-LAST:event_jBEditTiketActionPerformed

    private void jBDeletetiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBDeletetiketActionPerformed
          try  {
              String sql = "DELETE FROM tiket  WHERE Id_tiket = ?";
              PreparedStatement ps = conn.prepareStatement(sql);
              ps.setInt(1, Integer.parseInt(IdTiket.getText()));
              ps.executeUpdate();
              JOptionPane.showMessageDialog(this, "Data berhasil di hapus");
              loadDataTiket();
              clearInputFieldsTiket();
         } catch (SQLException e) {
              System.out.println("Error Save Data" + e.getMessage());
          }
    }//GEN-LAST:event_jBDeletetiketActionPerformed

    private void RBBiasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RBBiasaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RBBiasaActionPerformed

    private void tbl_penginapanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_penginapanMouseClicked
      tfNama.setText(tbl_penginapan.getValueAt(tbl_penginapan.getSelectedRow(), 0).toString());
      tfAlamat.setText(tbl_penginapan.getValueAt(tbl_penginapan.getSelectedRow(), 1).toString());
      tfNIK.setText(tbl_penginapan.getValueAt(tbl_penginapan.getSelectedRow(), 2).toString());
      tfTotal.setText(tbl_penginapan.getValueAt(tbl_penginapan.getSelectedRow(), 7).toString());
      jBTambahPenginapan.setEnabled(true);
      JBEditPenginapan.setEnabled(true);
      JBDeletePenginapan.setEnabled(true);
    }//GEN-LAST:event_tbl_penginapanMouseClicked

    private void jBTambahPenginapanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBTambahPenginapanActionPerformed
        try {
        String nama = tfNama.getText();
        String alamat = tfAlamat.getText();
        int nik = Integer.parseInt(tfNIK.getText());

        // Ambil tanggal dari JCalendar
        java.util.Date checkInDateUtil = tglChekIn.getDate();
        java.util.Date checkOutDateUtil = tglCheckOut.getDate();


        // Validasi tanggal
        if (checkInDateUtil == null || checkOutDateUtil == null) {
            JOptionPane.showMessageDialog(this, "Silakan pilih tanggal check-in dan check-out.");
            return;
        }

        // Mengkonversi java.util.Date ke java.time.LocalDate
        LocalDate checkInDate = checkInDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate checkOutDate = checkOutDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
       
        // Menghitung jumlah hari
        long JumlahHari = java.time.temporal.ChronoUnit.DAYS.between(checkInDate, checkOutDate);

        // Validasi jumlah hari
        if (JumlahHari <= 0) {
            JOptionPane.showMessageDialog(this, "Tanggal check-out harus lebih besar dari tanggal check-in.");
            return;
        }

        int harga = getSelectedHarga();
        int totalharga = harga * (int) JumlahHari; 
        tfTotal.setText("" + totalharga);
        
        if (harga <= 0) { 
        JOptionPane.showMessageDialog(this, "Silakan pilih harga terlebih dahulu.");
        return;
    }

        String sql = "INSERT INTO penginapan (Nama, Alamat, Harga, JumlahHari, Total, NIK, TglCheckIn, TglCheckOut) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, nama);
        ps.setString(2, alamat);
        ps.setInt(3, harga);
        ps.setInt(4, (int) JumlahHari);
        ps.setInt(5, totalharga);
        ps.setInt(6, nik);

        // Mengkonversi java.util.Date ke java.sql.Date
        ps.setDate(7, new java.sql.Date(checkInDateUtil.getTime()));
        ps.setDate(8, new java.sql.Date(checkOutDateUtil.getTime()));

        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan");

        loadDataPenginapan();
        clearInputFieldsPenginapan();
    } catch (SQLException e) {
        System.out.println("Error Save Data: " + e.getMessage());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Input data tidak valid: " + e.getMessage());
    }

    }//GEN-LAST:event_jBTambahPenginapanActionPerformed

    private void JBEditPenginapanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBEditPenginapanActionPerformed
        try{
        String nama = tfNama.getText();
        String alamat = tfAlamat.getText();
        int nik = Integer.parseInt(tfNIK.getText());
        

        // Ambil tanggal dari JCalendar
        java.util.Date checkInDateUtil = tglChekIn.getDate();
        java.util.Date checkOutDateUtil = tglCheckOut.getDate();


        // Validasi tanggal
        if (checkInDateUtil == null || checkOutDateUtil == null) {
            JOptionPane.showMessageDialog(this, "Silakan pilih tanggal check-in dan check-out.");
            return;
        }

        // Mengkonversi java.util.Date ke java.time.LocalDate
        LocalDate checkInDate = checkInDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate checkOutDate = checkOutDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        
        

        // Menghitung jumlah hari
        long jumlahHari = java.time.temporal.ChronoUnit.DAYS.between(checkInDate, checkOutDate);

        // Validasi jumlah hari
        if (jumlahHari <= 0) {
            JOptionPane.showMessageDialog(this, "Tanggal check-out harus lebih besar dari tanggal check-in.");
            return;
        }

        int harga = getSelectedHarga();
        int totalharga = harga * (int) jumlahHari; 
        tfTotal.setText("" + totalharga);
        
         if (harga <= 0) { 
        JOptionPane.showMessageDialog(this, "Silakan pilih harga terlebih dahulu.");
        return;
    }
        
        String sql = "UPDATE penginapan SET Nama = ?, Alamat = ?, Harga = ?, JumlahHari = ?, Total = ?, TglCheckIn = ?, TglCheckOut = ? WHERE NIK = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, nama);
        ps.setString(2, alamat);
        ps.setInt(3, harga);
        ps.setInt(4, (int) jumlahHari);
        ps.setInt(5, totalharga);
        ps.setDate(6, new java.sql.Date(checkInDateUtil.getTime()));
        ps.setDate(7, new java.sql.Date(checkOutDateUtil.getTime()));
        ps.setInt(8, nik);
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data berhasil di Edit");
        
        loadDataPenginapan();
        clearInputFieldsPenginapan();
      }catch(SQLException e){
          System.out.println("Error Save Data: " + e.getMessage());
      }catch (NumberFormatException e){
          JOptionPane.showMessageDialog(this, "Input data tidak valid : " + e.getMessage());
      }

    }//GEN-LAST:event_JBEditPenginapanActionPerformed

    private void JBDeletePenginapanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBDeletePenginapanActionPerformed
         try  {
              String sql = "DELETE FROM penginapan  WHERE NIK = ?";
              PreparedStatement ps = conn.prepareStatement(sql);
              ps.setInt(1, Integer.parseInt(tfNIK.getText()));
              ps.executeUpdate();
              JOptionPane.showMessageDialog(this, "Data berhasil di hapus");
              loadDataPenginapan();
              clearInputFieldsPenginapan();
         } catch (SQLException e) {
              System.out.println("Error Save Data" + e.getMessage());
          }
    }//GEN-LAST:event_JBDeletePenginapanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new wisata().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Harga;
    private javax.swing.JTextField HargaTiket;
    private javax.swing.JTextField IdTiket;
    private javax.swing.JButton JBDeletePenginapan;
    private javax.swing.JButton JBEditPenginapan;
    private javax.swing.JTextField Jumlahtiket;
    private javax.swing.JRadioButton RBBiasa;
    private javax.swing.JRadioButton RBElit;
    private javax.swing.JRadioButton RBMewah;
    private javax.swing.JRadioButton RBSVIP;
    private javax.swing.JRadioButton RBVIP;
    private javax.swing.JRadioButton RBVVIP;
    private javax.swing.JTextField TotalTiket;
    private javax.swing.JButton jBDeletetiket;
    private javax.swing.JButton jBEditTiket;
    private javax.swing.JButton jBTambahPenginapan;
    private javax.swing.JButton jBTambahTiket;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable tbl_Tiket;
    private javax.swing.JTable tbl_penginapan;
    private javax.swing.JTextField tfAlamat;
    private javax.swing.JTextField tfJumlahHari;
    private javax.swing.JTextField tfNIK;
    private javax.swing.JTextField tfNama;
    private javax.swing.JTextField tfTotal;
    private com.toedter.calendar.JDateChooser tglCheckOut;
    private com.toedter.calendar.JDateChooser tglChekIn;
    // End of variables declaration//GEN-END:variables

    private void login() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
